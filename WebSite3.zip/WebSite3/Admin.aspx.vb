﻿
Partial Class Admin
    Inherits System.Web.UI.Page

End Class
